! source file: /usr/local/models/UVic_ESCM/2.8/source/mom/csnap.h
!====================== include file "csnap.h" =========================

!     snapls = starting latitude (degs) for 1
!     snaple = ending latitude (degs) for 1
!     snapde = ending depth (centimeters) for 1

      common /csnap/ snapls, snaple, snapde
