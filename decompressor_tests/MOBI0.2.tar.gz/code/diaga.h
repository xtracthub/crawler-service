! source file: /usr/local/models/UVic_ESCM/2.8/source/mom/diaga.h
!====================== include file "diaga.h" =========================

!     variables used for computing diagnostics:

!     dc14bar  = total volume weighted delta c14
!     dc14     = delta c14

      common /cdiaga_r/ dc14bar, dc14(imt,km,jsmw:jemw)

!     totalk   = total number of levels involved in convection
!     vdepth   = ventilation depth (cm)
!     pe       = potential energy lost due to explicit convection (g/s2)

      common /cdiaga_r/ totalk(imt,jsmw:jemw), vdepth(imt,jsmw:jemw)
      common /cdiaga_r/ pe(imt,jsmw:jemw)
