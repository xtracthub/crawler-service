! source file: /usr/local/models/UVic_ESCM/2.8/source/mom/tcslab.h
!====================== include file "tcslab.h" ========================

!     slab block extensions for turbulent closure

       common /slabs/
     $                   q2(imt,km,nslabs,ntau)
     $,                  vdc(imt,km,nslabs,ntau)
     $,                  vvc(imt,km,nslabs,ntau)
     $,                  vdqc(imt,km,nslabs,ntau)

!     q2a   = buffer area to hold the updated "n+1" q2 slab data
!     vdca  = buffer area to hold the updated "n+1" kh slab data
!     vvca  = buffer area to hold the updated "n+1" km slab data
!     vdqca = buffer area to hold the updated "n+1" kq slab data
!     q2la  = buffer area to hold the updated "n+1" q2l slab data

       common /bufout/
     $                   q2a (imt,km)
     $,                  vdca(imt,km)
     $,                  vvca(imt,km)
     $,                  vdqca(imt,km)
