! source file: /usr/local/models/UVic_ESCM/2.8/source/mom/cpolar.h
!====================== include file "cpolar.h" =========================

!     polar transform coefficients used to transform velocities near
!     poles before filtering

      common /cpolar/ spsin(imt), spcos(imt)
