! source file: /usr/local/models/UVic_ESCM/2.8/source/mom/vmixc.h
!====================== include file "vmixc.h" =========================

!         vertical mixing coefficients and related variables

!     kappa_h = constant vertical diffusion coefficient (cm**2/sec)
!     kappa_m = constant vertical viscosity coefficient (cm**2/sec)

!     visc_cbu  = viscosity coeff at bottom of "u" cell
!     diff_cbt  = diffusion coeff at bottom of "T" cell
!     visc_cbu_limit = largest allowable "visc_cbu"
!     diff_cbt_limit = largest allowable "diff_cbt"
!     aidif = coefficient for implicit time differencing for
!             vertical diffusion. aidif=1 gives the fully implicit
!             case. aidif=0 gives the fully explicit case
!             note: not used unless "implicitvmix" or "isopycmix"
!                   is enabled

!     based on code by: R. C. Pacanowski
!=======================================================================

      real kappa_h,  kappa_m
      common /vmixr0/ visc_cbu_limit, diff_cbt_limit, aidif
      common /vmixr0/ kappa_h, kappa_m
      common /vmixr1/ visc_cbu(imt,km,jsmw:jemw)
      common /vmixr1/ diff_cbt(imt,km,jsmw:jemw)

