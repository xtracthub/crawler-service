! source file: /usr/local/models/UVic_ESCM/2.8/source/mom/hmixc.h
!======================= include file "hmixc.h" ========================

!                    horizontal mixing coefficients

!     visc_cnu = viscosity coeff for northern face of "u" cell
!     visc_ceu = viscosity coeff for eastern face of "u" cell
!     diff_cnt = diffusion coeff for northern face of "T" cell
!     diff_cet = diffusion coeff for eastern face of "T" cell

!     am     = constant lateral viscosity coeff for momentum
!     ah     = constant lateral diffusion coeff for tracers
!     am3    = viscosity coeff for metric term on "u" cell
!     am4    = another viscosity coeff for metric term on "u" cell
!     ambi   = constant lateral biharmonic viscosity coeff for momentum
!     ahbi   = constant lateral biharmonic diffusion coeff for tracers

!     based on code by: R. C. Pacanowski
!=======================================================================

      common /diffus0/ am, ambi, am3(jmt), am4(jmt,2)
      common /diffus0/ ah, ahbi
      common /diffus0/ visc_ceu, visc_cnu
      common /diffus0/ amc_north(jmt), amc_south(jmt)

      common /diffus0/ diff_cnt, diff_cet
      common /diffus0/ ahc_north(jmt), ahc_south(jmt)

