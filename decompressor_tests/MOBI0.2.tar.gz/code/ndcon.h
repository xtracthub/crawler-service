! source file: /usr/local/models/UVic_ESCM/2.8/source/common/ndcon.h
!====================== include file "ndcon.h" ========================

!     various non dimensional quantities:

!     radian = degrees per radian
!     pi     = something good to eat

      real radian, pi
      common /ndcon/ radian, pi
