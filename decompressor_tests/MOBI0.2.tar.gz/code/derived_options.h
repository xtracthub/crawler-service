! source file: /usr/local/models/UVic_ESCM/2.8/source/common/derived_options.h
! Do not edit the source file derived_options.h unless you are willing to
! remake all code. The mk script may not delete and remake all files that
! depend on derived options so files can become inconsistent.

