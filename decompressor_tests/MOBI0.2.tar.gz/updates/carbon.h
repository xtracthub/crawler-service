!====================== include file "carbon.h" =========================
      real phlo,phhi,sit_in,pt_in
      parameter(phlo = 6., phhi = 10., sit_in = 7.6875e-03 !mol/m^3
     &,         pt_in = 0.5125e-3)   !mol/m^3
